/* 046267 Computer Architecture - HW #1                                 */
/* This file should hold your implementation of the predictor simulator */

#include "bp_api.h"
#include <cmath>   // std::log2()
#include <string>  // std::sting
#include <cstdint> // ? Fixed width integer types (since C++11)

// ---*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-- //
// ? Aux Functions

// assumes function parmaters are valid
uint32_t get_tag(uint32_t pc, uint8_t tag_length, uint8_t index_length, uint8_t alignment = 2);
// assumes function parmaters are valid
uint32_t get_index(uint32_t pc, uint8_t index_length, uint8_t alignment = 2);

// ---*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-- //
// ? definitions

// the `: uint8_t` ensures that the enum integral type is uint8_t (for types to be the same)
enum fsm_state : uint8_t
{
	SNT = 0,
	WNT = 1,
	WT = 2,
	ST = 3
};

class BranchPredictor
{
public:
	BranchPredictor() = default; // initializes every type to 0
	~BranchPredictor();

	void update(uint32_t pc, uint32_t targetPc, bool taken, uint32_t pred_dst);

	/*
	 ? Useful
	 */
	uint32_t get_BTB_entry_branch_pc(uint32_t idx) { return __btb[idx].__branch_pc; }
	uint32_t get_BTB_entry_target_pc(uint32_t idx) { return __btb[idx].__target_pc; }
	void set_BTB_entry_branch_pc(uint32_t idx, uint32_t pc) { __btb[idx].__branch_pc = pc; }
	void set_BTB_entry_target_pc(uint32_t idx, uint32_t pc) { __btb[idx].__target_pc = pc; }
	bool is_BTB_entry_valid(uint32_t idx) { return __btb[idx].__valid; }
	void set_BTB_as_valid(uint32_t idx) { __btb[idx].__valid = true; }
	bool is_BTB_decisive() const { return (this->get_tag_size() + static_cast<uint8_t>(std::log2(this->get_btb_size())) + 2) == 32; }
	bool get_BTB_prediction(uint32_t index);

	/*
	 ? Init values Getters and Setters
	 */
	inline unsigned get_btb_size() const { return __btb_size; }
	inline unsigned get_history_size() const { return __history_size; }
	inline unsigned get_tag_size() const { return __tag_size; }
	inline unsigned get_fsm_default_state() const { return __fsm_default_state; }
	inline bool is_global_history() const { return __global_history; }
	inline bool is_global_table() const { return __global_table; }
	inline int get_share() const { return __share; }

	bool set_btb_size(unsigned btb_size) { __btb_size = btb_size; return true;}
	bool set_history_size(unsigned history_size) { __history_size = history_size; return true;}
	bool set_tag_size(unsigned tag_size) { __tag_size = tag_size; return true;}
	bool set_fsm_default_state(unsigned fsm_default_state) { __fsm_default_state = (fsm_state)fsm_default_state; return true;}
	bool set_global_history(bool global_history) { __global_history = global_history; return true;}
	bool set_global_table(bool global_table) { __global_table = global_table; return true;}
	bool set_share(int share) { __share = share; return true;}

	/*
	 ? Predictor operations
	 */
	bool create_BTB();
	bool create_history();
	bool create_fsm_table();

	/*
	 ? Stats Getters and Setters
	 */

	inline SIM_stats &get_stats() { return __stats; }
	inline unsigned &Stats_flush_num() { return __stats.flush_num; }
	inline unsigned &Stats_br_num() { return __stats.br_num; }
	inline unsigned &Stats_size() { return __stats.size; }

private:
	/*
	 ? Init values
	 */
	// valid values: 1,2,4,8,16,32
	unsigned __btb_size;
	// valid bit number: 1-8
	unsigned __history_size;
	// valid bit number: 0-( 32-log2[__btb_size]-2 )
	unsigned __tag_size;
	// valid values: enum fsm_state
	fsm_state __fsm_default_state;
	// true for global history
	bool __global_history;
	// true for global fsm
	bool __global_table;
	// using Lshare or Gshare, only relevant for global fsm (__global_table==true)
	// not_using_share == 0
	// using_share_lsb == 1 : XOR
	// using_share_mid == 2 : XOR
	int __share;

	/*
	 ? BTB entry
	 */
	struct BTB_entry
	{
		uint32_t __branch_pc;
		uint32_t __target_pc;
		bool __valid;
	};
	BTB_entry *__btb;

	/*
	 ? BTB History - local/global
	 */
	struct BTB_history
	{
		uint8_t __history_bit_map; // __history_bit_map contains the n bits for history (assuming __history_size is 8 bits max)
	};
	BTB_history *__history;

	/*
	 ? Bimodal fsm - local/global
	 */
	struct Bimodal_FSM
	{
		fsm_state *__bimodal_FSM_state; // 2 bits, stored in a byte for simplicity
	};
	Bimodal_FSM *__fsm;

	/*
	 ? Stats
	 */
	SIM_stats __stats;
};

// ---*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-- //
// ? Global data

BranchPredictor *BRANCH_PREDICTOR;

// ---*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-- //
// ? Function implementation

int BP_init(unsigned btbSize, unsigned historySize, unsigned tagSize, unsigned fsmState,
			bool isGlobalHist, bool isGlobalTable, int Shared)
{
	// * Create Branch Predictor
	BRANCH_PREDICTOR = new BranchPredictor(); // using the default c'tor
	// check if memory allocation is successful
	if (BRANCH_PREDICTOR == nullptr)
	{
		return -1;
	}

	// * Initialize init values
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_btb_size(btbSize) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_history_size(historySize) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_tag_size(tagSize) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_fsm_default_state(fsmState) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_global_history(isGlobalHist) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_global_table(isGlobalTable) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	// check if setting the value has failed
	if (BRANCH_PREDICTOR->set_share(Shared) == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}

	// * Allocate tables for BTB, history, fsm table
	if (BRANCH_PREDICTOR->create_BTB() == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	if (BRANCH_PREDICTOR->create_history() == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}
	if (BRANCH_PREDICTOR->create_fsm_table() == false)
	{
		delete BRANCH_PREDICTOR;
		return -1;
	}

	// * Initialize stats
	BRANCH_PREDICTOR->Stats_flush_num() = 0;
	BRANCH_PREDICTOR->Stats_br_num() = 0;
	// Calculate the number of bits for the BTB
	size_t total_bits = 0;
	total_bits += (BRANCH_PREDICTOR->get_tag_size() + 1) * (BRANCH_PREDICTOR->get_btb_size()); // (tag size + one valid bit) * (BTB size)
	if (BRANCH_PREDICTOR->is_global_history())
	{
		total_bits += BRANCH_PREDICTOR->get_history_size();
	}
	else
	{
		total_bits += BRANCH_PREDICTOR->get_btb_size() * BRANCH_PREDICTOR->get_history_size();
	}
	// 2^(historySize) == (1 << historySize)
	if (BRANCH_PREDICTOR->is_global_table())
	{
		total_bits += 2 * (1 << BRANCH_PREDICTOR->get_history_size());
	}
	else
	{
		total_bits += BRANCH_PREDICTOR->get_btb_size() * 2 * (1 << BRANCH_PREDICTOR->get_history_size());
	}
	BRANCH_PREDICTOR->Stats_size() = total_bits;

	return 0;
}

bool BP_predict(uint32_t pc, uint32_t *dst)
{
	// taken == true, not taken == false

	// * calculate BTB entry index
	int index = get_index(pc, (uint8_t)std::log2(BRANCH_PREDICTOR->get_btb_size()), 2);
	// ** check if tags are the same for
	uint32_t pc_tag = get_tag(pc, BRANCH_PREDICTOR->get_tag_size(), (uint8_t)std::log2(BRANCH_PREDICTOR->get_btb_size()), 2);
	uint32_t prediction_pc = BRANCH_PREDICTOR->get_BTB_entry_branch_pc(index);
	uint32_t prediction_tag = get_tag(prediction_pc, BRANCH_PREDICTOR->get_tag_size(), (uint8_t)std::log2(BRANCH_PREDICTOR->get_btb_size()), 2);
	if (pc_tag == prediction_tag) // same entry in BTB => possibly the same instruction
	{
		// return prediction
		bool taken = BRANCH_PREDICTOR->get_BTB_prediction(index);
		if (taken)
		{
			*dst = BRANCH_PREDICTOR->get_BTB_entry_target_pc(index);
			return true; // taken
		} // else => no taken == false
	}
	*dst = pc + 4; // Next sequential address
	return false;  // not taken
}

void BP_update(uint32_t pc, uint32_t targetPc, bool taken, uint32_t pred_dst)
{
	BRANCH_PREDICTOR->update(pc, targetPc, taken, pred_dst);
}

void BP_GetStats(SIM_stats *curStats)
{
	*curStats = BRANCH_PREDICTOR->get_stats();
	delete BRANCH_PREDICTOR;
	return;
}

// ---*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-----*-- //
// ? Aux Functions and Classes Function implementation

uint32_t get_tag(uint32_t pc, uint8_t tag_length, uint8_t index_length, uint8_t alignment)
{
	// ((1 << tag_length) - 1) is 0..01..1 where # of 1's is `tag_length`
	return (pc >> (alignment + index_length)) & ((1 << tag_length) - 1);
}

uint32_t get_index(uint32_t pc, uint8_t index_length, uint8_t alignment)
{
	/**
	 * (1 << index_length) gives a number of the form: 0...010...0 where # of LSB zeros is
	 * 	the index_length, removing 1 gives replaces the 1 by 0 and replaces the
	 * 	[index_length] LSB 0 bits to 1's, doing an & with this gives the [index_length] LSB
	 * 	bits of (pc >> alignment) where this is the (pc) without the padding 0's got from
	 * 	the alignment of the pc (if any).
	 */
	return (pc >> alignment) & ((1 << index_length) - 1);
}

BranchPredictor::~BranchPredictor()
{
	delete[] __btb;

	delete[] __history;

	if (__fsm)
	{
		if (this->is_global_table())
		{
			for (size_t i = 0; i < (1 << this->get_history_size()); i++)
			{
				delete[] __fsm->__bimodal_FSM_state;
			}
		}
		else
		{
			for (size_t j = 0; j < this->get_btb_size(); j++)
			{
				for (size_t i = 0; i < (1 << this->get_history_size()); i++)
				{
					delete[] __fsm[j].__bimodal_FSM_state;
				}
			}
		}
	}
	delete[] __fsm;
}

bool BranchPredictor::create_BTB()
{
	__btb = new BTB_entry[this->get_btb_size()];
	if (__btb == nullptr)
	{
		return false;
	}
	return true;
}

bool BranchPredictor::create_history()
{
	if (this->is_global_history())
	{
		// make only 1 history
		__history = new BTB_history[1];
	}
	else
	{
		// make |BTB| histories, one for each BTB entry
		__history = new BTB_history[this->get_btb_size()];
	}

	if (__history == nullptr)
	{
		return false;
	}
	return true;
}

bool BranchPredictor::create_fsm_table()
{
	if (this->is_global_table())
	{
		// make only 1 fsm table
		__fsm = new Bimodal_FSM[1];
		if (__fsm == nullptr)
		{
			return false;
		}
		__fsm->__bimodal_FSM_state = new fsm_state[1 << this->get_history_size()];
		if (__fsm->__bimodal_FSM_state == nullptr)
		{
			delete[] __fsm;
			return false;
		}
		// initialize it
		for (size_t j = 0; j < (1 << this->get_history_size()); j++)
		{
			(__fsm->__bimodal_FSM_state)[j] = (fsm_state)this->get_fsm_default_state();
		}
	}
	else
	{
		// make |BTB| fsm table(s), one for each BTB entry
		__fsm = new Bimodal_FSM[this->get_btb_size()];
		if (__fsm == nullptr)
		{
			return false;
		}
		for (size_t i = 0; i < this->get_btb_size(); i++)
		{
			__fsm[i].__bimodal_FSM_state = new fsm_state[1 << this->get_history_size()];
			if (__fsm[i].__bimodal_FSM_state == nullptr)
			{
				for (size_t j = 0; j < i; j++)
				{
					delete[] __fsm[j].__bimodal_FSM_state;
				}
				delete[] __fsm;
				return false;
			}
			// initialize it
			for (size_t j = 0; j < (1 << this->get_history_size()); j++)
			{
				(__fsm[i].__bimodal_FSM_state)[j] = (fsm_state)this->get_fsm_default_state();
			}
		}
	}
	return true;
}

bool BranchPredictor::get_BTB_prediction(uint32_t index)
{
	// taken == true, not taken == false

	// get history == fsm index
	uint32_t fsm_index;
	if (this->is_global_history())
	{
		fsm_index = __history->__history_bit_map;
	}
	else // local history
	{
		fsm_index = __history[index].__history_bit_map;
	}

	if (BRANCH_PREDICTOR->is_global_table())
	{
		if (BRANCH_PREDICTOR->get_share() == 1) // using_share_lsb == 1 : XOR history with bit 2 -> MSB
		{
			fsm_index ^= ((this->get_BTB_entry_branch_pc(index) >> 2) & ((1 << this->get_history_size()) - 1));
		}
		else if (BRANCH_PREDICTOR->get_share() == 2) // using_share_mid == 2 : XOR history with bit 16 -> MSB
		{
			fsm_index ^= ((this->get_BTB_entry_branch_pc(index) >> 16) & ((1 << this->get_history_size()) - 1));
		}
		// else don't change index using XOR

		// remember, __fsm is global
		return (__fsm->__bimodal_FSM_state[fsm_index] >= 2);
	}
	else // local table => __share doesn't matter
	{
		// remember, __fsm is local
		return (__fsm[index].__bimodal_FSM_state[fsm_index] >= 2);
	}
}

void BranchPredictor::update(uint32_t pc, uint32_t targetPc, bool taken, uint32_t pred_dst)
{

	// * update the stats
	// dealing with another branch instruction
	this->Stats_br_num()++;
	// mis-predictions causes a flush
	if (taken)
	{
		if (targetPc != pred_dst) // taken branch, but predicted not taken => mis-prediction
		{
			this->Stats_flush_num()++;
		}
	}
	else
	{
		if (targetPc == pred_dst) // not taken branch, but predicted taken => mis-prediction
		{
			this->Stats_flush_num()++;
		}
	}

	// * update the BTB
	// check if pc is already in BTB, if not our prediction is not taken
	uint32_t branch_index = get_index(pc, (uint8_t)std::log2(this->get_btb_size()), 2);
	uint32_t btb_branch_pc = this->get_BTB_entry_branch_pc(branch_index);
	uint32_t branch_tag = get_tag(pc, this->get_tag_size(), (uint8_t)std::log2(this->get_btb_size()), 2);
	uint32_t btb_branch_tag = get_tag(btb_branch_pc, this->get_tag_size(), (uint8_t)std::log2(this->get_btb_size()), 2);

	if (this->is_BTB_entry_valid(branch_index))
	{
		// if they have the same tag => potentially the same instruction
		if (branch_tag == btb_branch_tag)
		{
			// there can be cases where we can'y say for sure (be decisive) whether the branches in the BTB index are the same
			// if BTB is decisive we change the entry, if not we only update it the first time
			if (this->is_BTB_decisive())
			{
			}
			// else no init. is done
		}
		else // they are NOT the same instruction
		{
			// change the entry in the BTB for the new branch
			this->set_BTB_entry_branch_pc(branch_index, pc);
			this->set_BTB_entry_target_pc(branch_index, targetPc);
			// re-initialize the history and fsm
			if (!this->is_global_history()) // local history
			{
				__history[branch_index].__history_bit_map = 0;
			}
			if (!this->is_global_table()) // local fsm
			{
				if (this->is_global_history())
				{
					uint32_t fsm_index = branch_index;
					if (this->get_share() == 1) // using_share_lsb == 1 : XOR history with bit 2 -> MSB
					{
						fsm_index ^= ((this->get_BTB_entry_branch_pc(branch_index) >> 2) & ((1 << this->get_history_size()) - 1));
					}
					else if (this->get_share() == 2) // using_share_mid == 2 : XOR history with bit 16 -> MSB
					{
						fsm_index ^= ((this->get_BTB_entry_branch_pc(branch_index) >> 16) & ((1 << this->get_history_size()) - 1));
					}
					// else don't change index using XOR

					__fsm[branch_index].__bimodal_FSM_state[fsm_index] = this->__fsm_default_state;
				}
				else
				{
					__fsm[branch_index].__bimodal_FSM_state[__history[branch_index].__history_bit_map] = this->__fsm_default_state;
				}
			}
		}
	}
	else // BTB has no filled entry for the branch, make a new one
	{
		// mark the entry as valid
		this->set_BTB_as_valid(branch_index);
	}

	return;
}
